##  Spring Security with Digest Authentication

This module contains articles about digest authentication with Spring Security

### The Course

The "Learn Spring Security" Classes: http://github.learnspringsecurity.com

### Relevant Article: 

- [Spring Security Digest Authentication](https://www.baeldung.com/spring-security-digest-authentication)
- [RestTemplate with Digest Authentication](https://www.baeldung.com/resttemplate-digest-authentication)

