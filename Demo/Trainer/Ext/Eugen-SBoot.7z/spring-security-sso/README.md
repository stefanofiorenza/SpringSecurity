## Spring Security Single Sign On

This module contains modules about single-sign-on with Spring Security

### Relevant Articles:
- [Simple Single Sign-On with Spring Security OAuth2](https://www.baeldung.com/sso-spring-security-oauth2)
- [Spring Security Kerberos Integration](https://www.baeldung.com/spring-security-kerberos-integration)
