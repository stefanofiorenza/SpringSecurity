## Relevant articles:

- [Introduction to SPNEGO/Kerberos Authentication in Spring](https://www.baeldung.com/spring-security-kerberos)
- [Spring Security Kerberos Integration](https://www.baeldung.com/spring-security-kerberos-integration)
