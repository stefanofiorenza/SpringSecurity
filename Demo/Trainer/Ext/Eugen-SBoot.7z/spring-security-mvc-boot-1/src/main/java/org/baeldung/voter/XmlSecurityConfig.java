package org.baeldung.voter;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * Created by ambrusadrianz on 09/10/2016.
 */
// @Configuration
// @ImportResource({ "classpath:spring-security-custom-voter.xml" })
public class XmlSecurityConfig {
    public XmlSecurityConfig() {
        super();
    }
}
