package org.baeldung.ip.config;


//@Configuration
//@EnableWebSecurity
//@ImportResource({ "classpath:spring-security-ip.xml" })
public class SecurityXmlConfig {
   
}