## Spring Security X.509

This module contains articles about X.509 authentication with Spring Security 

### Relevant Articles:
- [X.509 Authentication in Spring Security](https://www.baeldung.com/x-509-authentication-in-spring-security)
